import scrapy
import logging


class Google_spider(scrapy.Spider):
    name = 'bspu'
    allowed_domains = ['bspu.ru']
    start_urls = ["https://bspu.ru/"]
    # FEED_EXPORT_ENCODING = "utf-8"
    # start_urls = ["https://bspu.ru/unit/61/"]
    custom_settings = {
        "FEED_EXPORT_ENCODING": "utf-8",
    }