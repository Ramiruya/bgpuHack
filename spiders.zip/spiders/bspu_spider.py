import scrapy
import logging


class BSPU_spider(scrapy.Spider):
    name = 'bspu'
    allowed_domains = ['bspu.ru']
    start_urls = ["https://bspu.ru/"]
    # FEED_EXPORT_ENCODING = "utf-8"
    # start_urls = ["https://bspu.ru/unit/61/"]
    custom_settings = {
        "FEED_EXPORT_ENCODING": "utf-8",
    }

    def parse(self, response):
        div = response.xpath('//div[@id="mn-block-1"]')
        for a in div.xpath('.//a'):
            href = a.xpath('./@href')
            logging.debug(href)
            # faculty_name = a.xpath('./text()').extract_first()
            # logging.debug(faculty_name)
            yield response.follow(href.get(), callback=self.parse_link_users)

    def parse_link_users(self, response):
        search_text = 'Сотрудники'
        faculty_users = response.xpath(f'//a[text()="{search_text}"]/@href')
        logging.warning('Получение ссылки на сотрудников %s', response)

        yield response.follow(faculty_users.get(), callback=self.parse_faculty)

    def parse_faculty(self, response):
        department = ''
        # logging.warning(response)
        # def parse(self, response):
        for section in response.xpath('//section[@class="p-b-1 docs-component"]'):
            for div in section.xpath('.//div[@class="media-body"]'):
                for h4 in div.xpath('.//h4'):
                    a = h4.xpath('.//a')
                    # logging.warning('wow')
                    faculty_name = a.xpath(
                        '//span[@class="header-title-text font-opiumnewc text-uppercase"]//text()').extract_first()
                    href = a.xpath('./@href').extract_first()
                    text = a.xpath('./text()').extract_first()
                    # logging.info(type(text))
                for div1 in div.xpath('.//div[@class="text-muted"]'):
                    department = div1.xpath('.//a/text()').extract_first()
                    post = div1.xpath('.//following-sibling::text()').get().strip()[2:]
                    yield {
                        'faculty_name': faculty_name,
                        'department': department,
                        'post': post,
                        'user_link': href,
                        'text': text
                    }
