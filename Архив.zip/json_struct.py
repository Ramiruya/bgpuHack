import json

def struct(input):
    # Чтение данных из JSON файла
    with open(input, 'r') as file:
        data = json.load(file)

    # Создание структурированного файла
    structured_data = {}
    for item in data:
        faculty_name = item['faculty_name']
        department = item['department']

        if faculty_name not in structured_data:
            structured_data[faculty_name] = {}

        if department not in structured_data[faculty_name]:
            structured_data[faculty_name][department] = []

        structured_data[faculty_name][department].append({
            'post': item['post'],
            'user_link': item['user_link'],
            'fio': item['fio']
        })

    # Запись структурированных данных в новый файл
    with open(input, 'w') as file:
        json.dump(structured_data, file, ensure_ascii=False, indent=4)