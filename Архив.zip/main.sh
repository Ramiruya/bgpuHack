#!/bin/bash
scrapy runspider main.py -o test.json
