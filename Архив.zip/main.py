import os
import subprocess
import google_parse_test
import json_struct
import search_fio


# Парсер сайта БГПУ для хакатона

# Запуск парсера сайта БГПУ
def run_spider(spider_name, json):
    process = subprocess.Popen(['scrapy', 'runspider', spider_name, '-o', json])
    process.wait()

if __name__ == '__main__':
    # удаление старого json с результатами парсинга БГПУ
    json_bspu = './data.json'
    os.remove(json_bspu)
    create_json = open(json_bspu, 'w+')
    create_json.close()
    # Запуск парсинга БГПУ
    run_spider('./spiders/bspu_spider.py', json_bspu)
    # Структурирование полученного json
    json_struct.struct(json_bspu)


    # run_spider('./spiders/google_spider.py')
    # google_parse_test.func1()
    # По скольку гугл имеет свойство банить за слишком частое обращение, поиск статей
    # происходит по интересующему пользователя фио сотрудника

    search_fio.select_fio(json_bspu)