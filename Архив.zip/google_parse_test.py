import requests
from bs4 import BeautifulSoup
import json
def scholar_search(query):
    # Construct the search URL
    query = query.replace(" ", "+")
    url = f'https://scholar.google.com/scholar?hl=ru&as_sdt=0%2C5&q={query}'

    # Send a GET request to the URL
    response = requests.get(url)

    # Parse the HTML content of the page with BeautifulSoup
    soup = BeautifulSoup(response.content, 'html.parser')

    # Find all the article results
    results = soup.find_all('h3', class_='gs_rt')

    # Extract the article titles and links
    articles = []
    for result in results:
        link = result.find('a')['href']
        title = result.text
        articles.append({'title': title, 'link': link})
    print(articles)
    for article in articles:
        print(f'<a href="{article["link"]}">{article["title"]}</a>')
    return
    # return articles

# Example usage
# for article in articles:
#     print(f'<a href="{article["link"]}">{article["title"]}</a>')